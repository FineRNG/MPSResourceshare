using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class PriorityHolder : MonoBehaviour
{
    private int random;
    public float PriorityPoints;
    void Start()
    {
        int random = Random.Range(0, 1);
        Debug.Log("Object Instance");
    }
    void update()
    {


        if (random < 2)
        {
            PriorityPoints = PriorityPoints - 5;
        }


    }
}
