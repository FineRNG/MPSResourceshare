using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirectorBasic : MonoBehaviour
{
    public float DelayBetweenTicks;
    public float TimeLeft;
    public bool Send = false;
    public PathfindBasic packageReceiver;

    // Start is called before the first frame update
    void Start()
    {
        TimeLeft = DelayBetweenTicks;


    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (TimeLeft > 0)
            TimeLeft -= Time.deltaTime;
        else
        {
            Send = true;
            TimeLeft = DelayBetweenTicks;
            EncodeData();
        }

        //Find Values of Interactibles

        void EncodeData()
        {
            //creating a unique package per interactible object
            GameObject[] taggedObjects = GameObject.FindGameObjectsWithTag("AIInteractible");
            foreach (GameObject taggedObject in taggedObjects)
            {
                //defining PriorityHolder
                PriorityHolder Holder = taggedObject.GetComponent<PriorityHolder>();
                //If there are any PriorityHolder objects detected
                if (Holder != null)
                {
                    //assigning value to position and the "priorityPoints" variable in the script
                    Vector3 position = taggedObject.transform.position;
                    float value = Holder.PriorityPoints;
                    // Create a package with the position and value
                    Package package = new Package(position, value);

                    // Use the package as needed
                    Debug.Log("Package created: " + package.ToString());

                    // Send the package to the PackageReceiver for processing
                    packageReceiver.ReceivePackage(package);
                }

            }
        }


    }
    // Custom package class to store position and value
    public class Package
    {
        public Vector3 position;
        public float value;
        //"This.x" is used to make clear specifications about which container of "package is being referred to (the one in this example is a reference to 
        //the package that is to be sent, rather than a reference to the class;
        public Package(Vector3 position, float value)
        {
            this.position = position;
            this.value = value;
        }
        //Override method here is used to convert the given variables to readable variables when the .ToString method is called
        public override string ToString()
        {
            return "Position: " + position.ToString() + ", Value: " + value.ToString();
        }
        public float GetValue()
        {
            return value;
        }
    }
}
