using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class PathfindBasic : MonoBehaviour
{
    public DirectorBasic directorBasic;
    public NavMeshAgent agent;
    private Vector3 Target;
    public string phase;
    public Transform Player; // The target the AI will be watching
    public Light aiLight;
    private enum AIState
    {
        Phase1,
        Phase2,
        Phase3
    }

    private AIState currentState;

    // Start is called before the first frame
    // 
    void Awake()
    {
        directorBasic = directorBasic.GetComponent<DirectorBasic>();
        Light aiLight = GetComponent<Light>();

    }

    void Start()
    {
        phase = "locate";
        currentState = AIState.Phase1;
    }

    // Update is called once per frame
    void Update()
    {
        if (directorBasic.Send == true)
        {

            Debug.Log("Message Recieved");
            directorBasic.Send = false;
            // Sort the received packages by value
            SortPackagesByValue();

            // Connect the packages to their corresponding positions
            ConnectPackagesToPositions();
            Target = GetHighestValuePosition();
            if(currentState == AIState.Phase1)
            agent.SetDestination(Target);

        }



        switch (currentState)
        {
            case AIState.Phase1:
                // Perform actions for Phase 1
                // Check if the AI has reached the desired point

                if (HasReachedPoint())
                {
                    // Transition to Phase 2
                    TransitionToPhase2();
                }
                break;

            case AIState.Phase2:
                // Perform actions for Phase 2
                // Check if the AI has line of sight to the target

                if (HasLineOfSight())
                {
                    // Transition to watch phase
                    TransitionToWatchPhase();
                }
                break;

            // Add more cases for additional phases, if needed

            default:
                break;
        }
    }
    private List<DirectorBasic.Package> packages = new List<DirectorBasic.Package>();
    //Note: Only keep lines related to packages and decryption of packages
    public void ReceivePackage(DirectorBasic.Package package)
    {
        packages.Add(package);
    }

    public void SortPackagesByValue()
    {
        packages.Sort((p1, p2) => p2.GetValue().CompareTo(p1.GetValue()));
    }

    public void ConnectPackagesToPositions()
    {
        foreach (DirectorBasic.Package package in packages)
        {
            // Retrieve the value of the package
            float value = package.GetValue();

            // Connect the package to its corresponding Vector3 position
            // Implement your logic here to perform the desired action
            Debug.Log("Package Value: " + value + ", Position: " + package.position);
        }
    }

    public Vector3 GetHighestValuePosition()
    {
        if (packages.Count > 0)
        {
            DirectorBasic.Package highestValuePackage = packages[0];
            return highestValuePackage.position;
        }

        // Return a default Vector3 if there are no packages
        return Vector3.zero;
    }


    private bool HasReachedPoint()
    {
        // Implement logic to check if the AI has reached the desired point
        // Return true if the AI has reached the point, false otherwise
        // Example implementation:
        return Vector3.Distance(transform.position, Target) < 2f;
    }

    private bool HasLineOfSight()
    {
        // Implement logic to check if the AI has line of sight to the target
        // Return true if the AI has line of sight, false otherwise
        // Example implementation:
        RaycastHit hit;
        if (Physics.Linecast(transform.position, Player.position, out hit))
        {
            if (hit.transform == Player)
            {
                return true;
            }
        }
        return false;
    }

    private void TransitionToPhase2()
    {
        currentState = AIState.Phase2;
        // Perform any necessary actions when transitioning to Phase 2
    }

   
    private void TransitionToWatchPhase()
    {
        // Find a suitable location based on the criteria
        Vector3 targetPosition = Player.position; // Target position to consider for distance calculation
        float maxDistance = 20f; // Maximum distance from the target
        float maxObstruction = 1f; // Maximum line of sight obstruction (0 fully obscured, 1 fully clear)
        float maxLightLevel = 0.1f; // Maximum light level (0 darkest, 1 brightest)
        float fixedY = 1.4f;
        Vector3 suitableLocation = FindSuitableLocation(targetPosition, maxDistance, maxObstruction, maxLightLevel, fixedY);

        // Set the AI's position to the suitable location
        currentState = AIState.Phase3;
        agent.SetDestination(suitableLocation);
        // Perform any other necessary actions for the watch phase
        Debug.Log(suitableLocation);
    }

    private Vector3 FindSuitableLocation(Vector3 targetPosition, float maxDistance, float maxObstruction, float maxLightLevel, float fixedY)
    {
        Vector3[] possibleLocations = new Vector3[10]; // Array to store potential locations
        int validLocationCount = 0; // Counter for valid locations

        for (int i = 0; i < possibleLocations.Length; i++)
        {
            Vector3 randomLocation = GetRandomLocationNearTarget(targetPosition, maxDistance);
            float lineOfSightObstruction = GetLineOfSightObstruction(randomLocation);
            float lightLevel = GetLightLevel(randomLocation);

            // Set the Y coordinate to the fixedY value
            randomLocation.y = fixedY;

            if (lineOfSightObstruction <= maxObstruction && lightLevel <= maxLightLevel)
            {
                possibleLocations[validLocationCount] = randomLocation;
                validLocationCount++;
            }
        }

        if (validLocationCount > 0)
        {
            // Choose a random valid location from the array
            int randomIndex = Random.Range(0, validLocationCount);
            return possibleLocations[randomIndex];
        }

        // If no suitable location is found, return the target's position with the fixed Y coordinate
        return new Vector3(targetPosition.x, fixedY, targetPosition.z);
    }

    private Vector3 GetRandomLocationNearTarget(Vector3 targetPosition, float maxDistance)
    {
        // Implement logic to generate a random location near the target within the specified maxDistance
        // Example implementation:
        Vector3 randomDirection = Random.insideUnitSphere * maxDistance;
        return targetPosition + randomDirection;
    }

    private float GetLineOfSightObstruction(Vector3 location)
    {
        // Implement logic to calculate the line of sight obstruction at the given location
        // You can use raycasts or other methods to determine the level of obstruction
        // Return a value between 0 (fully obscured) and 1 (fully clear)
        // Example implementation:
        RaycastHit hit;
        if (Physics.Linecast(transform.position, location, out hit))
        {
            if (hit.transform != Player)
            {
                return 0f; // Fully obscured
            }
        }
        return 1f; // Fully clear
    }

    public float GetLightLevel(Vector3 location)
    {
        // Implement logic to calculate the light level at the given location
        // You can use light probes, global illumination, or other methods to determine the light level
        // Return a value between 0 (darkest) and 1 (brightest)
        // Example implementation:
        // Assuming you have a Light component attached to the AI character:
        float distanceToLocation = Vector3.Distance(transform.position, location);
        float lightIntensity = aiLight.intensity / (distanceToLocation * distanceToLocation); // Light intensity diminishes with distance
        return lightIntensity;
    }

}
